﻿namespace Practicle4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student student= new Student("jimit patel");     
            student.Getmarks();
            student.ChooseOptions();
        }
    }
}