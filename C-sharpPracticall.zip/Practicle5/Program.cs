﻿namespace Practicle5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ArrayDemo arraydemo = new ArrayDemo();
            arraydemo.GetData();
            arraydemo.PrintArray();
        }
    }
}