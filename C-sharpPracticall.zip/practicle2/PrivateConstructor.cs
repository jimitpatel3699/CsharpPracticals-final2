﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practicle2
{
     public class PrivateConstructor
     {
        static internal string Division="Csp" ;
        

        private PrivateConstructor()
        {
           
        }

        static decimal Sum(int Num1, int Num2)
        { 
            return Num1 + Num2;
        }


        
      }
}
