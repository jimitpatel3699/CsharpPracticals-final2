﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practicle2
{
    internal class ParameterlessConstructor
    {
        string Id;
        public string Name;

        internal ParameterlessConstructor()
        {
            Id = "21it100085";
            Name = "jimit";
        }

        
    }
}
