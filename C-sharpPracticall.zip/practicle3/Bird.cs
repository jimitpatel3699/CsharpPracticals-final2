﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace practicle3
{
    //create class for perform polymorphism demo.
    internal class Bird
    {
        public void Voice()
        {
            Console.WriteLine("Turr Turr");
        }
    }
}
